package jspSmart;

@SuppressWarnings("serial")
public class SmartUploadException extends Exception {

	SmartUploadException(String s) {
		super(s);
	}
}
